### Instruction
run python wall_follower.py

please its not complicated